# FollowTask Android

Aplikasi pendamping Android untuk mengelola daftar tugas secara lokal.

## Fitur
- Tambah username dan reward secara manual.
- Simpan tugas di database lokal Room.
- Buka profil Instagram melalui Android Intent.
- Konfirmasi penyelesaian dilakukan oleh pengguna.
- Jeda 5 detik setelah konfirmasi.
- Notifikasi ketika jeda selesai (memerlukan izin notifikasi).

## Batasan integrasi
Versi ini tidak mengambil data langsung dari PR.social dan tidak melakukan follow otomatis.
Sinkronisasi PR.social hanya boleh ditambahkan melalui API/fitur ekspor resmi yang diizinkan.
Aplikasi tidak meminta atau menyimpan kata sandi Instagram.

## Cara membuka
1. Ekstrak ZIP.
2. Buka folder `FollowTaskAndroid` melalui Android Studio.
3. Gunakan JDK 17 dan Android SDK Platform 35.
4. Tunggu Gradle Sync.
5. Jalankan aplikasi pada perangkat Android atau emulator.

Untuk membuat APK: Android Studio > Build > Build Bundle(s) / APK(s) > Build APK(s).

## Build APK melalui GitHub Actions
Workflow build tersedia di `.github/workflows/build-apk.yml`. Untuk menjalankannya,
proyek harus memiliki Gradle Wrapper (`gradlew`, `gradlew.bat`, dan `gradle/wrapper/`).
Buat wrapper dengan Gradle 8.9 menggunakan `gradle wrapper --gradle-version 8.9`,
lalu commit seluruh file wrapper. Setelah proyek diunggah ke GitHub, jalankan workflow
"Build FollowTask APK" dari tab Actions dan unduh artifact `FollowTask-debug-apk`.
