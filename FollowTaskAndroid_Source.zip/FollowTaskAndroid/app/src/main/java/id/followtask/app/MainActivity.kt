package id.followtask.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TaskNotifier.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val dao = TaskDatabase.get(this).taskDao()
        setContent {
            MaterialTheme {
                FollowTaskScreen(
                    dao = dao,
                    onOpenProfile = { username ->
                        val clean = username.trim().removePrefix("@")
                        val intent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://www.instagram.com/$clean/")
                        )
                        startActivity(intent)
                    },
                    onDelayFinished = { TaskNotifier.notifyNext(this) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FollowTaskScreen(
    dao: TaskDao,
    onOpenProfile: (String) -> Unit,
    onDelayFinished: () -> Unit
) {
    val context = LocalContext.current
    val tasks by dao.observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    var username by remember { mutableStateOf("") }
    var reward by remember { mutableStateOf("0.002") }
    var countdown by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("Tambahkan tugas atau impor username secara manual.") }

    val completed = tasks.count { it.completed }
    val earned = tasks.filter { it.completed }.sumOf { it.rewardUsd }

    LaunchedEffect(countdown) {
        if (countdown > 0) {
            delay(1000)
            countdown -= 1
            if (countdown == 0) {
                message = "Jeda selesai. Tugas berikutnya siap."
                onDelayFinished()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("FollowTask")
                        Text("Instagram task assistant", style = MaterialTheme.typography.labelSmall)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ElevatedCard {
                Column(Modifier.padding(16.dp)) {
                    Text("Estimasi reward selesai", style = MaterialTheme.typography.labelMedium)
                    Text("$" + "%.3f".format(earned), style = MaterialTheme.typography.headlineMedium)
                    Text("$completed dari ${tasks.size} tugas selesai")
                }
            }

            Text("Tambah tugas", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Username Instagram") },
                singleLine = true
            )
            OutlinedTextField(
                value = reward,
                onValueChange = { reward = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Reward (USD)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true
            )
            Button(
                onClick = {
                    val name = username.trim()
                    val amount = reward.toDoubleOrNull()
                    if (name.isNotBlank() && amount != null && amount >= 0) {
                        scope.launch { dao.insert(Task(username = name, rewardUsd = amount)) }
                        username = ""
                        message = "Tugas ditambahkan."
                    } else {
                        message = "Periksa username dan nominal reward."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Tambahkan ke antrean")
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Antrean tugas", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.weight(1f))
                Text("${tasks.size} tugas", style = MaterialTheme.typography.labelMedium)
            }

            if (tasks.isEmpty()) {
                Text("Belum ada tugas. Tambahkan username di atas.")
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(tasks, key = { it.id }) { task ->
                        ElevatedCard {
                            Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("Ikuti di Instagram", style = MaterialTheme.typography.titleSmall)
                                        Text(task.username, style = MaterialTheme.typography.bodyMedium)
                                        Text("$" + "%.3f".format(task.rewardUsd), style = MaterialTheme.typography.labelMedium)
                                    }
                                    if (task.completed) {
                                        AssistChip(onClick = {}, label = { Text("Selesai") })
                                    } else {
                                        IconButton(onClick = { onOpenProfile(task.username) }) {
                                            Icon(Icons.Default.OpenInNew, contentDescription = "Buka profil")
                                        }
                                    }
                                }
                                if (!task.completed) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(
                                            onClick = { onOpenProfile(task.username) },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Buka Instagram") }
                                        Button(
                                            onClick = {
                                                scope.launch {
                                                    dao.markCompleted(task.id)
                                                    countdown = 5
                                                    message = "Tugas dikonfirmasi. Menunggu 5 detik..."
                                                }
                                            },
                                            modifier = Modifier.weight(1f)
                                        ) { Text("Konfirmasi") }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (countdown > 0) {
                LinearProgressIndicator(
                    progress = { (5 - countdown) / 5f },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Text(
                if (countdown > 0) "Tugas berikutnya dalam $countdown detik" else message,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
