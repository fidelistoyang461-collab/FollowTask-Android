package id.followtask.app

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val rewardUsd: Double = 0.002,
    val completed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
